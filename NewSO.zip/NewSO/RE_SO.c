#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MEMORY_SIZE 20
// instrucoes quaisquer
char instString[20][20] = {"HALT","MOV AX, 0","ADD AX, 4","MOV BX, AX","PUSH AX","MOV AX, 10",
"MOV AX, 0","ADD AX, 4","MOV BX, AX","PUSH AX","MOV AX, 10",
"MOV AX, 0","ADD AX, 4","MOV BX, AX","PUSH AX","MOV AX, 10","MOV AX, 0","ADD AX, 4","MOV BX, AX","PUSH AX"};

int memory[MEMORY_SIZE] = {0};
int memoryUse = 0;
int createDefragBuffer = -1;

// a posição do processo é o id
// User = 1; SO = 2(create), 4 (kill), 3(mode), negative: finished processes

// Process
int process[200] = {0};

int selected = 0;

int order = 0;

int forcesw = 0;

int unselected = 0;

// char instructions[5][10] = {"NOP","HALT", "ADD", "SUB","MOV"};

int processSize[200] = {0};
int processToEnd[200] = {0};
// i+1
int processStartMem[200] = {0};
int processEndMem[200] = {0};

int mode = 0;
int conter = 0;

void allocateProcess(int size, int index) {
    for (int i = index; i < (size+index); i++) {
        memory[i] = order;
        if(i==index){
            processStartMem[order] = i;
        }
        if(i==(size+index-1)){
            processEndMem[order] = i;
        }
    }
    processToEnd[order]=size-1;
    processSize[order]=size;
    order++;
}

void createProcess(int size) {
    int memCount = 0;
    int memStart = 0;
    int memControl = 0;
    if(size > (20-memoryUse)){
        printf("\nNot enough space\n");
    }else
    for (int i = 0; i < MEMORY_SIZE; i++) {
        if (memory[i] == 0) {
            memCount++;
            if(memControl == 0){
                memStart = i;
                memControl++;
            }
        } else if(memory[i] != 0){
            memCount = 0;
            memStart = 0;
            memControl = 0;
        }
        if (memCount >= size) {
            process[order]=1;
            memoryUse+=size;
            allocateProcess(size, memStart);
            return;
        }
        if(i == MEMORY_SIZE-1){
            if(createDefragBuffer != selected){
                createDefragBuffer=selected;
                processToEnd[selected]++;
                conter--;
                printf("Defragmentation needed, one buffer per create\n");
            }else {
                printf("\nCreate failed\n");
                killProcess(selected);}
        }
    }
}

void killProcess(int killID) {
    int valid;
    valid = 0;
    if(process[killID]==1){
        for (int i = 0; i <20; i++) {
            if(memory[i]==killID){
                memory[i]=0;
                valid = 1;
            }
        }if(valid ==1){        
            memoryUse-=processSize[killID];
            processStartMem[killID]=0;
            processEndMem[killID]=0;
            process[killID]=0-process[killID];
            processToEnd[killID]=-1;
        }else printf("Invalid kill Id");
    }else {
        printf("\nSO process ended: %d",killID);
        process[killID]=0-process[killID];
    }
}

void desfrag(){
    int space,foundZero,pid;
    space = 0;foundZero = 0;    
    for (int i = 0; i < MEMORY_SIZE; i++) {
        if(memory[i]==0){
            foundZero = 1;
            space++;
        }else
        if(memory[i] > 0){
            pid=memory[i];
            if(foundZero > 0){
                processStartMem[pid] = processStartMem[pid]- space;
                processEndMem[pid] = processEndMem[pid] - space;
                for (int j = processStartMem[pid]; j < processEndMem[pid]+1; j++) {
                    memory[j]=pid;
                }
                for (int k = processEndMem[pid]+1; k < (processEndMem[pid]+space+1); k++) {
                    memory[k]=0;
                }
            }
            i=processEndMem[pid];
            foundZero=0;
            space=0;
        }
    }
}

void queueProcess(int type,int value){
    // entra na fila de processos e coloca 'seu parametro' no processSize(por conveniencia)
    if(type == 1){
        process[order] = 2;
        processSize[order] = value;
        processToEnd[order]=0;
        order++;
    }
    else if(type == 2){
        process[order] = 4;
        processSize[order] = value;
        processToEnd[order]=0;
        order++;
        
    }
    else if(type == 3){
        process[order] = 3;
        processSize[order] = value;
        processToEnd[order]=0;
        order++; 
    }
}

void selectProcess(){
    int circle;
    circle = 0;
    if(forcesw==1){
        for (int i = selected+1; i < 200; i++) {
            if(process[i] > 0){
                selected = i;
                i = 200;
            }
            if(i == 199){
                circle=1;
            }
        }
        if(circle == 1){
            for (int i = 0; i < selected+1; i++) {
                if(process[i] > 0){
                    selected = i;
                    i = 200;
                }
                if(i == selected){
                    unselected=1;
                    printf("No process to select");
                }
            }
        }
    }else
    // Robin
    if(mode!=0){
        for (int i = selected+1; i < 200; i++) {
            if(process[i] > 0){
                selected = i;
                i = 200;
            }
            if(i == 199){
                circle=1;
            }
        }
        if(circle == 1){
            for (int i = 0; i < selected+1; i++) {
                if(process[i] > 0){
                    selected = i;
                    i = 200;
                }
                if(i == selected){
                    unselected=1;
                    printf("No process to select");
                }
            }
        }
    // FIFO
    }else for (int i = 0; i < 200; i++) {
            if(process[i] > 0){
                selected = i;
                i = 200;
            }
            if(i == 199){
                unselected=1;
                printf("No process to select");
            }
        }
}

void runProcess(){
    if(process[selected] == 1){
        printf("\nExecuting: %s\n",instString[processToEnd[selected]]);
    }
    else if(process[selected] == 2){
        createProcess(processSize[selected]);
    }
    else if(process[selected] == 3){
        mode = processSize[selected];
    } 
    else if(process[selected] == 4){
        killProcess(processSize[selected]);
    }
    processToEnd[selected]--;
    if(processToEnd[selected] < 0){
        killProcess(selected);
        selectProcess();
        conter=0;
        printf("\n");
    }
}

// simula um ciclo
void runCycle(){
    if(unselected==1){
        selectProcess();
        unselected=0;
    }
    if(processToEnd[selected]>=0){
        printf("\nCycles to finish: %d\n",processToEnd[selected]);
        runProcess();
    }
    // FIFO
    if(mode == 0){
        if(processToEnd[selected] < 0){
            selectProcess();
        }
    }
    // Robin,duracao do round depende do valor de mode
    else{
        if(mode <= conter || processToEnd[selected] < 0){
            conter = 0;
            selectProcess();
        }
        conter++;
    }
}

int main() {
    char input[50];
    int value;

    FILE *fptr;
    fptr = fopen("mode.txt", "r");
    char myString[100];
    fgets(myString, 100, fptr);
    fclose(fptr);
    mode = (int)myString[0]-48;

    while (1) {
        system("cls");
        forcesw=0;

        printf("\nMode: %d",mode);
        printf("\nConter: %d",conter);
        printf("\nSelected: %d",selected);
        printf("\nOrder: %d",order);
        printf("\nMemory Use: %d",memoryUse);
        if(selected>=0){
            printf("\nMem:      ");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                if(memory[i]<0){
                    printf("|%d ",memory[i]);
                }else{
                    printf("| %d ",memory[i]);
                }
            }
            printf("\nProc:     ");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                if(process[i]<0){
                    printf("|%d ",process[i]);
                }else{
                    printf("| %d ",process[i]);
                }
            }
            printf("\nValues:   ");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                if(processSize[i]<0){
                    printf("|%d ",processSize[i]);
                }else{
                    printf("| %d ",processSize[i]);
                }
            }
            printf("\nStartInMem");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                if(processStartMem[i]<0){
                    printf("|%d ",processStartMem[i]);
                }else{
                    printf("| %d ",processStartMem[i]);
                }
            }
            printf("\nEndInMem  ");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                if(processEndMem[i]<0){
                    printf("|%d ",processEndMem[i]);
                }else{
                    printf("| %d ",processEndMem[i]);
                }
            }
            printf("\nTo End:   ");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                if(processToEnd[i]<0){
                    printf("|%d ",processToEnd[i]);
                }else{
                    printf("| %d ",processToEnd[i]);
                }
            }
        }

        printf("\n\nCommands: (-i is an intant argument, comand ignores priority order)\n");
        printf("create -m x           (x is the size and cicles to end)\n");
        printf("kill x  ||  kill -i x (x is the id of the process to kill)\n");
        printf("mode x  ||  mode -i x (x is the mode, 0 =Fifo, >0 RondRobin with x rounds)\n");
        printf("defrag                (defrag is an instant command,desfragmentation)\n");
        printf("forcesw               (forcesw is an instant command,force context swap)\n");
        printf("Enter -> run 1 cicle\n");

        printf("Enter command: ");
        fgets(input, sizeof(input), stdin);
        if (strncmp(input, "create -m", 9) == 0 && sscanf(input + 10, "%d", &value) == 1) {
            queueProcess(1,value);

        } else if (strncmp(input, "kill", 4) == 0 && sscanf(input + 5, "%d", &value) == 1) {
            queueProcess(2,value);

        }else if (strncmp(input, "kill -i", 7) == 0 && sscanf(input + 8, "%d", &value) == 1) {
            killProcess(value);
            selectProcess();

        } else if (strncmp(input, "defrag", 6) == 0){
            // o comando desfrag é "assincrono, roda imediatamente"
            printf("\nInstant desfragmentation");
            desfrag();
        } else if (strncmp(input, "forcesw", 7) == 0){
            // o comando desfrag é "assincrono, roda imediatamente"
            printf("\nForce Swap");
            forcesw=1;
            selectProcess();

        }  else if (strncmp(input, "mode", 4) == 0 && sscanf(input + 5, "%d", &value) == 1){
            queueProcess(3,value);

        }else if (strncmp(input, "mode -i", 7) == 0 && sscanf(input + 8, "%d", &value) == 1){
            printf("\nInstant mode change");
            mode = value;
        } else if (input[0] == '\n'){
            //skip
            runCycle();
        }  else printf("Invalid command\n");
                
        FILE *outputFile = fopen("memory_output.txt", "w");
        if (outputFile != NULL) {
            fprintf(outputFile, "\n");
            fprintf(outputFile, "Process (ID: %d) | Size: %d\n", selected, processSize[selected]+1);
            // if(processToEnd[selected]+1 > 0){
            //     fprintf(outputFile, "\nExecuting: %s\n",instString[processToEnd[selected]]);
            // }
            // if(processToEnd[selected]-1>0){
            //     fprintf(outputFile, "\nExecuting: %s\n",instString[processToEnd[selected]]);
            // }
            fprintf(outputFile, "\nExecuting: %s\n",instString[processToEnd[selected]]);
    

            fprintf(outputFile, "Memory Map: ");
            for (int i = 0; i < MEMORY_SIZE; i++) {
                fprintf(outputFile, "%d ", memory[i]);
            }
            fprintf(outputFile, "\n");
        
            fclose(outputFile);
        }
    }
    return 0;
}