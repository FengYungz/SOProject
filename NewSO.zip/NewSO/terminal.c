#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h> 


int main() {
    while (1) {
        system("cls");

        FILE *outputFile = fopen("memory_output.txt", "r");
        if (outputFile != NULL) {
                char linha[100]; // Buffer para armazenar cada linha do arquivo

                while (fgets(linha, sizeof(linha), outputFile) != NULL) {
                    printf("%s\n", linha); // Imprime a linha lida, pulando para uma nova linha
               
                }
            fprintf(outputFile, "\n");
            fclose(outputFile);
        }
         sleep(2);
    }
    return 0;
}